export class News {
     id: String;
    headline: String;
    url: String;
    topic: String;
    blog: String;
    site: String;
    newNo: String;
}	
