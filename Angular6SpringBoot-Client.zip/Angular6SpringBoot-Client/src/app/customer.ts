export class Customer {
    id: number;
    firstname: string;
    lastname: string;
    address: string;
    phone: string;
    active: boolean;
}	
